﻿

function smyFunction() {
    $("#message").val('');
}

